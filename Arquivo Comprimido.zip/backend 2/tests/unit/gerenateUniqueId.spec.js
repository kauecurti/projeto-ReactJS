const genereteUniqueId = require('../../src/utils/genereteUniqueId');


describr('Generate Unique Id', () => {
    it('should generete an unique ID', () => {
        const id = genereteUniqueId();
        
        expect(id).toHavelength(8)
    });
});