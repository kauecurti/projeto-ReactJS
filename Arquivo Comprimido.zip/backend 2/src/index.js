const express = require('express');
const cors = require('cors');
const { errors } = require('celebrate');
const routes = require('./routes');
const app = express();


app.use(cors());
app.use(express.json());
app.use(routes);
app.use(errors());

/**
 * 
 * Metodos get 
 * 
 * GET: buscar uma informaçao do back-end
 * POST: criar uma informaçao no back-end
 * PUT: altera uma informaçao no back-end
 * DELETE: Deletar uma informaçao no back-end
 */

 /**
  * Tipos de parantros
  * 
  * Query Params: Parametros nomeados enviados na rota apos o simbolo de "?" (Filtros de paginaçao)
  * Route Params: Paramentros utilizados para identificar recursos 
  * Request Body: Corpo da requisiçåo , utilizado para criar ou alterar recursos 
  */

/**
 * SQL: MySQL, SQLite, PostgreSQL, Oracle, Microsoft SQL Server
 * NoSQL: MongoDB, CouchDB, etc
 */



app.listen(3333);
